from .connect4_engine import *

__doc__ = connect4_engine.__doc__
if hasattr(connect4_engine, "__all__"):
    __all__ = connect4_engine.__all__